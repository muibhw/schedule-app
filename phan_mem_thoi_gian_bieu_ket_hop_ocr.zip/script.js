let events = JSON.parse(localStorage.getItem("scheduleEvents")) || [];

const imageInput = document.getElementById("imageInput");
const preview = document.getElementById("preview");

imageInput.addEventListener("change", () => {
  const file = imageInput.files[0];
  if (!file) return;

  preview.src = URL.createObjectURL(file);
  preview.style.display = "block";
});

function save() {
  localStorage.setItem("scheduleEvents", JSON.stringify(events));
}

function render() {
  const body = document.getElementById("scheduleBody");
  body.innerHTML = "";

  events.sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));

  events.forEach((ev, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${ev.date || ""}</td>
      <td>${ev.start || ""} - ${ev.end || ""}</td>
      <td><b>${escapeHtml(ev.title || "")}</b></td>
      <td>${escapeHtml(ev.place || "")}</td>
      <td>${escapeHtml(ev.note || "")}</td>
      <td><button class="danger" onclick="deleteEvent(${index})">Xóa</button></td>
    `;
    body.appendChild(row);
  });
}

function addManualEvent() {
  const ev = {
    title: document.getElementById("title").value.trim(),
    date: document.getElementById("date").value,
    start: document.getElementById("start").value,
    end: document.getElementById("end").value,
    place: document.getElementById("place").value.trim(),
    note: document.getElementById("note").value.trim()
  };

  if (!ev.title || !ev.date || !ev.start) {
    alert("Vui lòng nhập ít nhất: tên lịch, ngày và giờ bắt đầu.");
    return;
  }

  events.push(ev);
  save();
  render();
  clearManualForm();
}

function clearManualForm() {
  ["title", "date", "start", "end", "place", "note"].forEach(id => {
    document.getElementById(id).value = "";
  });
}

async function readImage() {
  const file = imageInput.files[0];
  if (!file) {
    alert("Vui lòng chọn ảnh trước.");
    return;
  }

  const status = document.getElementById("status");
  status.innerText = "Đang đọc chữ từ ảnh...";

  try {
    const result = await Tesseract.recognize(file, "eng+vie", {
      logger: m => {
        if (m.status === "recognizing text") {
          status.innerText = "Đang xử lý: " + Math.round(m.progress * 100) + "%";
        }
      }
    });

    document.getElementById("ocrText").value = result.data.text.trim();
    status.innerText = "Đã đọc xong. Kiểm tra lại nội dung rồi bấm chuyển thành lịch.";
  } catch (error) {
    status.innerText = "Không đọc được ảnh. Hãy kiểm tra mạng hoặc chọn ảnh rõ hơn.";
    console.error(error);
  }
}

function convertOCRToSchedule() {
  const text = document.getElementById("ocrText").value.trim();
  if (!text) {
    alert("Chưa có nội dung để chuyển.");
    return;
  }

  const before = events.length;
  const parsed = parseScheduleLines(text, true);
  events.push(...parsed);
  save();
  render();

  const added = events.length - before;
  alert(`Đã thêm ${added} lịch từ hình ảnh.`);
}

function importText() {
  const text = document.getElementById("bulkText").value.trim();
  if (!text) return alert("Bạn chưa dán nội dung lịch.");

  const parsed = parseScheduleLines(text, true);
  events.push(...parsed);
  save();
  render();

  alert(`Đã nhập ${parsed.length} lịch.`);
}

function parseScheduleLines(text, allowSmartDetect = false) {
  const lines = text.split("\n").map(line => line.trim()).filter(Boolean);
  const parsed = [];

  for (const line of lines) {
    if (line.includes("|")) {
      const parts = line.split("|").map(x => x.trim());
      if (parts.length >= 4) {
        parsed.push({
          title: parts[0] || "Không có tên việc",
          date: normalizeDate(parts[1]),
          start: normalizeTime(parts[2]),
          end: normalizeTime(parts[3]),
          place: parts[4] || "",
          note: parts[5] || ""
        });
      }
      continue;
    }

    if (allowSmartDetect) {
      const date = findDate(line);
      const times = findTimes(line);

      if (date && times.length >= 1) {
        parsed.push({
          title: cleanTitle(line, date, times),
          date,
          start: times[0] || "",
          end: times[1] || "",
          place: findPlace(line),
          note: ""
        });
      }
    }
  }

  return parsed.filter(e => e.title && e.date && e.start);
}

function importFile() {
  const input = document.getElementById("fileInput");
  const file = input.files[0];
  if (!file) return alert("Vui lòng chọn file.");

  const reader = new FileReader();
  reader.onload = e => {
    const content = e.target.result;

    if (file.name.endsWith(".csv")) {
      importCSV(content);
    } else if (file.name.endsWith(".ics")) {
      importICS(content);
    } else {
      alert("Chỉ hỗ trợ .csv hoặc .ics");
    }

    save();
    render();
  };

  reader.readAsText(file);
}

function importCSV(content) {
  const lines = content.split("\n").filter(Boolean);
  let startIndex = lines[0].toLowerCase().includes("title") ? 1 : 0;

  for (let i = startIndex; i < lines.length; i++) {
    const cols = lines[i].split(",").map(x => x.replace(/^"|"$/g, "").trim());
    events.push({
      title: cols[0] || "",
      date: normalizeDate(cols[1] || ""),
      start: normalizeTime(cols[2] || ""),
      end: normalizeTime(cols[3] || ""),
      place: cols[4] || "",
      note: cols[5] || ""
    });
  }
}

function importICS(content) {
  const blocks = content.split("BEGIN:VEVENT").slice(1);
  blocks.forEach(block => {
    const title = getICSValue(block, "SUMMARY");
    const location = getICSValue(block, "LOCATION");
    const description = getICSValue(block, "DESCRIPTION");
    const dtStart = getICSValue(block, "DTSTART");
    const dtEnd = getICSValue(block, "DTEND");

    events.push({
      title: title || "Không có tiêu đề",
      date: parseICSDate(dtStart),
      start: parseICSTime(dtStart),
      end: parseICSTime(dtEnd),
      place: location || "",
      note: description || ""
    });
  });
}

function getICSValue(block, key) {
  const line = block.split("\n").find(l => l.startsWith(key));
  if (!line) return "";
  return line.substring(line.indexOf(":") + 1).replace(/\\n/g, " ").trim();
}

function parseICSDate(value) {
  if (!value || value.length < 8) return "";
  return `${value.slice(0,4)}-${value.slice(4,6)}-${value.slice(6,8)}`;
}

function parseICSTime(value) {
  if (!value || value.length < 13) return "";
  return `${value.slice(9,11)}:${value.slice(11,13)}`;
}

function findDate(text) {
  let match = text.match(/\b(20\d{2})[-\/\.](\d{1,2})[-\/\.](\d{1,2})\b/);
  if (match) return `${match[1]}-${pad(match[2])}-${pad(match[3])}`;

  match = text.match(/\b(\d{1,2})[-\/\.](\d{1,2})[-\/\.](20\d{2})\b/);
  if (match) return `${match[3]}-${pad(match[2])}-${pad(match[1])}`;

  return "";
}

function normalizeDate(value) {
  const found = findDate(value);
  return found || value;
}

function findTimes(text) {
  const matches = text.match(/\b\d{1,2}[:h]\d{0,2}\b/g) || [];
  return matches.map(normalizeTime).filter(Boolean);
}

function normalizeTime(value) {
  if (!value) return "";
  let clean = String(value).trim().replace("h", ":");
  if (clean.endsWith(":")) clean += "00";
  const parts = clean.split(":");
  if (!parts[0]) return "";
  return `${pad(parts[0])}:${pad(parts[1] || "00")}`;
}

function findPlace(text) {
  const keywords = ["phòng", "phong", "room", "lớp", "lop", "cơ sở", "co so", "online", "zoom", "meet"];
  const lower = text.toLowerCase();

  for (const key of keywords) {
    const index = lower.indexOf(key);
    if (index !== -1) return text.slice(index).trim();
  }

  return "";
}

function cleanTitle(line, date, times) {
  let title = line;

  title = title.replace(date, "");
  title = title.replace(/\b20\d{2}[-\/\.]\d{1,2}[-\/\.]\d{1,2}\b/g, "");
  title = title.replace(/\b\d{1,2}[-\/\.]\d{1,2}[-\/\.]20\d{2}\b/g, "");

  for (const time of times) {
    const [h, m] = time.split(":");
    title = title.replace(new RegExp(`\\b${Number(h)}[:h]${m}\\b`, "g"), "");
    title = title.replace(new RegExp(`\\b${h}[:h]${m}\\b`, "g"), "");
    title = title.replace(new RegExp(`\\b${Number(h)}h\\b`, "g"), "");
  }

  const place = findPlace(title);
  if (place) title = title.replace(place, "");

  title = title.replace(/[-–—|]+/g, " ").replace(/\s+/g, " ").trim();
  return title || "Không có tên việc";
}

function downloadCSV() {
  const header = "title,date,start,end,place,note\n";
  const rows = events.map(e =>
    [e.title, e.date, e.start, e.end, e.place, e.note]
      .map(v => `"${String(v || "").replace(/"/g, '""')}"`)
      .join(",")
  ).join("\n");

  downloadFile("thoi_gian_bieu.csv", header + rows);
}

function downloadICS() {
  let ics = "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Thoi Gian Bieu OCR//VI\n";

  events.forEach(e => {
    const start = toICSDateTime(e.date, e.start);
    const end = toICSDateTime(e.date, e.end || e.start);
    ics += "BEGIN:VEVENT\n";
    ics += `SUMMARY:${safeICS(e.title)}\n`;
    ics += `DTSTART:${start}\n`;
    ics += `DTEND:${end}\n`;
    ics += `LOCATION:${safeICS(e.place)}\n`;
    ics += `DESCRIPTION:${safeICS(e.note)}\n`;
    ics += "END:VEVENT\n";
  });

  ics += "END:VCALENDAR";
  downloadFile("thoi_gian_bieu.ics", ics);
}

function toICSDateTime(date, time) {
  if (!date || !time) return "";
  return date.replaceAll("-", "") + "T" + time.replace(":", "") + "00";
}

function safeICS(text) {
  return String(text || "").replace(/\n/g, "\\n").replace(/,/g, "\\,");
}

function downloadFile(filename, content) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function deleteEvent(index) {
  events.splice(index, 1);
  save();
  render();
}

function clearAll() {
  if (confirm("Bạn có chắc muốn xóa toàn bộ thời gian biểu?")) {
    events = [];
    save();
    render();
  }
}

function pad(value) {
  return String(value || "0").padStart(2, "0");
}

function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

render();
